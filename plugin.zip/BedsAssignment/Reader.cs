﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace BedsAssignment
{
    public class Reader
    {
        public static List<Illness> readIllnessInformation(string illnessData, string columnDelimiter, string rowDelimiter)
        {
            List<Illness> illnessParsedData = new List<Illness>();
            var illnessRows = illnessData.Split(new string[] { rowDelimiter }, StringSplitOptions.None).ToList();
            illnessRows.ForEach(row =>
            {
                var cols = row.Split(new string[] { columnDelimiter }, StringSplitOptions.None).ToList();
                illnessParsedData.Add(new Illness(cols.ElementAt(0), cols.ElementAt(1)));
            });
            return illnessParsedData;
        }

        public static List<BedInformation> readBedsInformation(string bedsData, string columnDelimiter, string rowDelimiter)
        {
            List<BedInformation> bedsParsedData = new List<BedInformation>();
            var bedsRows = bedsData.Split(new string[] { rowDelimiter }, StringSplitOptions.None).ToList();
            bedsRows.ForEach(row =>
            {
                var cols = row.Split(new string[] { columnDelimiter }, StringSplitOptions.None).ToList();
                bedsParsedData.Add(new BedInformation(
                    cols.ElementAt(0),
                    cols.ElementAt(1),
                    cols.ElementAt(2),
                    cols.ElementAt(3),
                    cols.ElementAt(4),
                    cols.ElementAt(5),
                    cols.ElementAt(6),
                    cols.ElementAt(7),
                    cols.ElementAt(8),
                    cols.ElementAt(9),
                    cols.ElementAt(10),
                    cols.ElementAt(11),
                    cols.ElementAt(12),
                    cols.ElementAt(13),
                    cols.ElementAt(14)
                    ));
            });
            return bedsParsedData;
        }

        public static Config readAssignmentConfiguration(string config)
        {
            return JsonConvert.DeserializeObject<Config>(config);
        }

        public static AssignmentConfiguration readAssignment(string config)
        {
            return JsonConvert.DeserializeObject<AssignmentConfiguration>(config);
        }
    }
}
