﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BedsAssignment
{
    public class Illness
    {
        public string code { get; set; }
        public string isContagious { get; set; }

        public Illness(string code, string isContagious)
        {
            this.code = code;
            this.isContagious = isContagious;
        }
    }

    public class BedInformation
    {
        public string department { get; set; }
        public string sector { get; set; }
        public string room { get; set; }
        public string bed { get; set; }
        public string patientId { get; set; }
        public string patientName { get; set; }
        public string patientStreet { get; set; }
        public string patientPostalCode { get; set; }
        public string patientCity { get; set; }
        public string patientCountry { get; set; }
        public string illnessCode { get; set; }
        public string acceptedOn { get; set; }
        public string medicinesRequired { get; set; }
        public string equipmentUsed { get; set; }
        public string projectedDischargeDate { get; set; }

        public BedInformation(string department, string sector, string room, string bed, string patientId, string patientName, string patientStreet,
            string patientPostalCode, string patientCity, string patientCountry, string illnessCode, string acceptedOn, string medicinesRequired,
            string equipmentUsed, string projectedDischargeDate)
        {
            this.department = department;
            this.sector = sector;
            this.room = room;
            this.bed = bed;
            this.patientId = patientId;
            this.patientName = patientName;
            this.patientStreet = patientStreet;
            this.patientPostalCode = patientPostalCode;
            this.patientCity = patientCity;
            this.patientCountry = patientCountry;
            this.illnessCode = illnessCode;
            this.acceptedOn = acceptedOn;
            this.medicinesRequired = medicinesRequired;
            this.equipmentUsed = equipmentUsed;
            this.projectedDischargeDate = projectedDischargeDate;
        }
    }

    public class AssignmentConfiguration
    {
        public string comparisonMethod { get; set; }
        public string classificationMethod { get; set; }
        public string identifierOneSource { get; set; }
        public string identifierOneColumn { get; set; }
        public string identifierOneValue { get; set; }
        public string identifierTwoSource { get; set; }
        public string identifierTwoColumn { get; set; }
        public string identifierTwoValue { get; set; }

        public AssignmentConfiguration(string comparisonMethod, string classificationMethod, string identifierOneSource,
            string identifierOneColumn, string identifierOneValue, string identifierTwoSource, string identifierTwoColumn, string identifierTwoValue)
        {
            this.comparisonMethod = comparisonMethod;
            this.classificationMethod = classificationMethod;
            this.identifierOneSource = identifierOneSource;
            this.identifierOneColumn = identifierOneColumn;
            this.identifierOneValue = identifierOneValue;
            this.identifierTwoSource = identifierTwoSource;
            this.identifierTwoColumn = identifierTwoColumn;
            this.identifierTwoValue = identifierTwoValue;
        }
    }

    public class Config
    {
        public List<AssignmentConfiguration> assignmentConfiguration { get; set; }
    }
}
