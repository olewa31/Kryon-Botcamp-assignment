﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace BedsAssignment
{
    public class Tests
    {
        [Fact]
        public void testJsonConverter()
        {
            var config = "[[{\"comparisonMethod\":\"notEqual\",\"classificationMethod\":\"allowed\",\"identifierOneSource\":\"illness\",\"identifierOneColumn\":\"is_contagious\",\"identifierOneValue\":\"yes\"},{\"comparisonMethod\":\"columnBased\",\"classificationMethod\":\"allowed\",\"identifierOneSource\":\"illness\",\"identifierOneColumn\":\"code\",\"identifierOneValue\":\"broken_bone\",\"identifierTwoSource\":\"patient\",\"identifierTwoColumn\":\"department_id\",\"identifierTwoValue\":\"surgical\"}]]";
            var act = Reader.readAssignmentConfiguration(config);
            var exp = "";
            Assert.Matches(exp, "");
        }
    }
}
