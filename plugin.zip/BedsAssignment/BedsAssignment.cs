﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Kryon.Leo.Infrastructure.Plugin.Library;
using Kryon.Leo.Infrastructure.Plugin.Library.Attributes;

namespace BedsAssignment
{
    public class BedsAssignment : LeoPlugIn
    {
        public override void Initialize()
        {
            //do nothing
        }

        public override void Shutdown()
        {
            //do nothing
        }

        public override string Name
        {
            get { return "BedsAssignment"; }
        }

        [LeoPlugInMethod]
        public string assignBed(string bedsData, string illnessData, string currentPatientIllnessCode, string rowDelimiter, string colDelimiter)
        {
            try
            {
                var allBedsInformation = Reader.readBedsInformation(bedsData, colDelimiter, rowDelimiter);
                var allIllnessInformation = Reader.readIllnessInformation(illnessData, colDelimiter, rowDelimiter);

                var matchinIllness = allIllnessInformation.Where(x => x.code == currentPatientIllnessCode).ToList();
                if (matchinIllness.Count != 1)
                {
                    throw new Exception($"Expected only one matching illness. Got {matchinIllness.Count}");
                }
                var isContagious = matchinIllness.ElementAt(0).isContagious;

                //if is contagious then get beds from rooms with one bed only
                if (String.Equals(isContagious, "yes", StringComparison.OrdinalIgnoreCase))
                {
                    //var allowedBeds = allBedsInformation.GroupBy(x => new { x.department, x.sector, x.room }).Where(g => g.Count() == 1).Where(y => String.IsNullOrWhiteSpace(y.First().patientId)).Select(final => final.First()).ToList();
                    //if (allowedBeds.Count > 0)
                    //{
                    //    var foundItem = allowedBeds.ElementAt(0);
                    //    var indexFound = allBedsInformation.FindIndex(x => x.department == foundItem.department && x.sector == foundItem.sector
                    //    && x.room == foundItem.room && x.bed == foundItem.bed) + 2;
                    //    return indexFound.ToString();
                        
                    //}
                    //else
                    //{
                        var foundIndex = -1;
                        for (int i = 0; i < allBedsInformation.Count; i++)
                        {
                            var foundRooms = allBedsInformation.Where(x => x.department == allBedsInformation.ElementAt(i).department
                            && x.sector == allBedsInformation.ElementAt(i).sector && x.room == allBedsInformation.ElementAt(i).room).ToList();
                            if (foundRooms.Count > 1)
                            {
                                var validRoom = true;
                                for (int j = 0; j < foundRooms.Count; j++)
                                {
                                    if (!String.IsNullOrWhiteSpace(foundRooms.ElementAt(j).patientId))
                                    {
                                        validRoom = false;
                                    }
                                }
                                if (validRoom)
                                {
                                    foundIndex = i + 1;
                                    break;
                                }
                            }
                        }
                        return foundIndex.ToString();
                    //}

                }
                else
                {
                    var foundIndex = -1;
                    for (int i = 0; i < allBedsInformation.Count; i++)
                    {
                        if (String.IsNullOrWhiteSpace(allBedsInformation.ElementAt(i).patientId))
                        {
                            var foundRooms = allBedsInformation.Where(x => x.department == allBedsInformation.ElementAt(i).department
                            && x.sector == allBedsInformation.ElementAt(i).sector && x.room == allBedsInformation.ElementAt(i).room).ToList();
                            if (foundRooms.Count > 1)
                            {
                                var validRoom = true;
                                for (int j = 0; j < foundRooms.Count; j++)
                                {
                                    if (!String.IsNullOrWhiteSpace(foundRooms.ElementAt(j).patientId))
                                    {
                                        //check if current patient has contagious illness
                                        if (!String.IsNullOrWhiteSpace(foundRooms.ElementAt(j).illnessCode))
                                        {
                                            var currentPatientIsContagious = allIllnessInformation.Where(x => x.code == foundRooms.ElementAt(j).illnessCode).First().isContagious;
                                            if (String.Equals(currentPatientIsContagious, "yes", StringComparison.OrdinalIgnoreCase))
                                            {
                                                validRoom = false;
                                            }
                                        }
                                    }
                                }
                                if (validRoom)
                                {
                                    foundIndex = i + 1;
                                    break;
                                }
                            }
                        }
                    }
                    return foundIndex.ToString();
                }   
            }
            catch (Exception e)
            {
                return $"ERROR: {e.ToString()}";
            }
        }
    }
}
